% UQ for increased data points in the 2-dimensional GIB.
% Author: Regina Cai

clear all;
close all;

n_x = 2;
n_y = 1;
sigma_X = eye(n_x);
sigma_Y = eye(n_y);
sigma_XY = [0.1; 0.2];

% Choose beta.
beta = 100;
% Choose n (number of data points observed).
n = 10;
% Choose m (number of times to sample the Wishart distribution).
m = 20;

Data = sample_wishart(sigma_X, sigma_Y, sigma_XY, beta, n, m);

% Plot different values of W, A, and beta_crit
allW = cell2mat(Data(:,1));
allA = cell2mat(Data(:,2));
allbeta_crit = cell2mat(Data(:,3));

figure;
title('Histogram of sampled covariance matrix');
for i=1:((n_x+n_y)^2)
    index = 1:(m+1);
    row = ceil(i/(n_x+n_y));
    index = index*row;
    col = i-3*(row-1);
    
    true = allW(index(1),col);
    
    subplot(3,3,i);
    % use histcounts if need actual values
    histogram(allW(index(2:end),col),10);
    hold on;
    line([true,0],[true,10]);
    hold off;
    % dotplot(allW(index,col));
end


figure;
title('Histogram of output matrices corresponding to sampled covariance matrix');
for i=1:4
    index = 1:(m+1);
    row = ceil(i/2);
    index = index*row;
    col = i-2*(row-1);
    
    true = allA(index(1),col);
    subplot(2,2,i);
    histogram(allA(index(2:end),col),10);
    % scatter(allA(index(2:end),col),ones(m,1));
    hold on;
    line([true,0],[true,10]);
    % scatter(allA(index(1),col),1,'MarkerFaceColor',[0 0.5 0.5]);
    hold off;
    % dotplot(allW(index,col));
end

