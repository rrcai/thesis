% Analyze how the beta critical values change as the Sigma matrix changes.

n_x = 2;
n_y = 1;
sigma_x = 1;
sigma_y = b;
sigma_X = sigma_x*eye(n_x);
sigma_Y = sigma_y*eye(n_y);
sigma_XY = [0.1; 0.2];

sigma_XcondY = sigma_X-sigma_XY*inv(sigma_Y)*sigma_XY';
B = sigma_XcondY/sigma_X;
% Requires MATLAB R2014b
[V,eval,evec] = eig(B);

