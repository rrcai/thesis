function [ ConvLin_data, ConvQuad_data, FiltConvLin_data1, ...
    FiltConvQuad_data1, FiltConvLin_data2, FiltConvQuad_data2 ] = ...
    plotErrorConv( sigma_X, sigma_Y, sigma_XY, ...
    beta, m, allN)
% plotErrorConv returns error convergence data for the elements of A. 

n_x = size(sigma_X, 2);

% Set up array to store values. 
ConvLin_data = zeros(size(allN,2)-1, (n_x)+1);
ConvLin_data(:,1) = allN(1:end-1);
ConvQuad_data = zeros(size(allN,2)-1, (n_x)+1);
ConvQuad_data(:,1) = allN(1:end-1);
EstA_data = zeros(size(allN,2), n_x+1);

[TrueA, Truebeta_crit] = gib_optimize(sigma_X,sigma_Y,sigma_XY,beta);

for n = 1:size(allN,2);
    Data = sample_wishart(sigma_X, sigma_Y, sigma_XY, beta, allN(n), m);

    % Plot different values of W, A, and beta_crit
    allA = cell2mat(Data(:,2));
    allBeta_crit = cell2mat(Data(:,3));

    indices = (((1:(size(allBeta_crit,1)/2)).*2)-1)';
    thisBetacritData = allBeta_crit(indices,1);
    
    % A will always be n_x by n_x. 
    for k = 1:2
        % For this element of A and this value of n, find the mean 
        % square error. 
        row = -rem(ceil(k/2),2)+2*(1:(m+1));
        col = rem(k,2);
        if (col == 0)
            col = 2;
        end

        thisAData = allA(row,col);
        indices = logical(thisBetacritData < beta);
        EstA_data(n,k+1) = sum(thisAData(indices))/sum(indices);
   end
end

ConvLin_data(:,2) = (EstA_data(2:end,2)-TrueA(1,1))./(EstA_data(1:end-1,2)-TrueA(1,1));
ConvLin_data(:,3) = (EstA_data(2:end,3)-TrueA(1,2))./(EstA_data(1:end-1,3)-TrueA(1,2));
ConvQuad_data(:,2) = (EstA_data(2:end,2)-TrueA(1,1))./((EstA_data(1:end-1,2)-TrueA(1,1)).^2);
ConvQuad_data(:,3) = (EstA_data(2:end,3)-TrueA(1,2))./((EstA_data(1:end-1,3)-TrueA(1,2)).^2);

% Subset without outliers
FiltConvLin_data1 = [ConvLin_data(logical(abs(ConvLin_data(:,2)) < 50),1) ConvLin_data(logical(abs(ConvLin_data(:,2)) < 50),2)];
FiltConvLin_data2 = [ConvLin_data(logical(abs(ConvLin_data(:,3)) < 50),1) ConvLin_data(logical(abs(ConvLin_data(:,3)) < 50),3)];
FiltConvQuad_data1 = [ConvQuad_data(logical(abs(ConvQuad_data(:,2)) < 5000),1) ConvQuad_data(logical(abs(ConvQuad_data(:,2)) < 5000),2)];
FiltConvQuad_data2 = [ConvQuad_data(logical(abs(ConvQuad_data(:,3)) < 5000),1) ConvQuad_data(logical(abs(ConvQuad_data(:,3)) < 5000),3)];

end

