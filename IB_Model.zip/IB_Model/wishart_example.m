n_x = 2;
n_y = 1;
sigma_x = 1;
sigma_y = 1;
sigma_X = sigma_x*eye(n_x);
sigma_Y = sigma_y*eye(n_y);
sigma_XY = [0.1; 0.2];

n = 1000;
max = 10000;

Sigma = [sigma_X, sigma_XY; sigma_XY.', sigma_Y];
err = zeros((n_x+n_y),(n_x+n_y));
for m=1:max
    W = wishrnd(Sigma, n)/n;
    err = err+abs(W-Sigma);
end
err = err./max